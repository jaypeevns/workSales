package com.sales.workbench.SalesWorkbench.models;

import org.springframework.data.annotation.Id;

public class OrderItems {
	@Id
	private Integer id;
	private String order_id;
	private String product_id;
	private String quantity;
	private String order_value;
	
    public OrderItems() {
    }
	
	public OrderItems(String order_id, String product_id, String quantity, String order_value) {
		super();
		this.order_id = order_id;
		this.product_id = product_id;
		this.quantity = quantity;
		this.order_value = order_value;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getOrder_id() {
		return order_id;
	}

	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}

	public String getProduct_id() {
		return product_id;
	}

	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getOrder_value() {
		return order_value;
	}

	public void setOrder_value(String order_value) {
		this.order_value = order_value;
	}	
}
