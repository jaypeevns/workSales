package com.sales.workbench.SalesWorkbench.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;
import org.springframework.dao.EmptyResultDataAccessException;

import com.sales.workbench.SalesWorkbench.models.Order;

@Repository
public class OrderRepository {
	private static final String SQL_FIND_BY_ID = "SELECT * FROM ORDER WHERE ID = :id";
    private static final String SQL_FIND_ALL = "SELECT * FROM ORDER";
    private static final String SQL_INSERT = "INSERT INTO ORDER "
    		+ "(PRODUCTID, USERID, ORCERVALUE, ADDRESS, CITY, PINCODE, EMAIL, MOBILENUMBER, PAYMENTMODE, ISRETURNED, CREATEDAT ) "
    		+ "values(:product_ids, :user_id, :order_value, :address, :city, :pincode, :email, :mobile_Number, :payment_mode, :is_returned, :created_at)";
    private static final String SQL_UPDATE_BY_ID = "UPDATE ORDER "
    		+ "SET ADDRESS=:address, CITY=:city, PINCODE=:pincode, EMAIL=:email, MOBILENUMBER=:mobile_Numbe WHERE ID = :id";

    private static final BeanPropertyRowMapper<Order> ROW_MAPPER = new BeanPropertyRowMapper<>(Order.class); 
    
    @Autowired
    NamedParameterJdbcTemplate jdbcTemplate;
    
    public Order findById(Integer id) {
        try {
            final SqlParameterSource paramSource = new MapSqlParameterSource("id", id);
            return jdbcTemplate.queryForObject(SQL_FIND_BY_ID, paramSource, ROW_MAPPER);
        }
        catch (EmptyResultDataAccessException ex) {
            return null;
        }
    }
    
    public Iterable<Order> findAll() {
        return jdbcTemplate.query(SQL_FIND_ALL, ROW_MAPPER);
    }

    public int save(Order order) {
        final SqlParameterSource paramSource = new MapSqlParameterSource()
                .addValue("product_ids", order.getProduct_ids())
                .addValue("user_id", order.getUser_id())
                .addValue("order_value", order.getOrder_value())
                .addValue("address", order.getAddress())
                .addValue("city", order.getCity())
                .addValue("pincode", order.getPincode())
                .addValue("email", order.getEmail())
                .addValue("mobile_Number", order.getMobile_Number())
                .addValue("payment_mode", order.getPayment_mode())
                .addValue("is_returned", order.getIs_returned())
                .addValue("created_at", order.getCreated_at());

        return jdbcTemplate.update(SQL_INSERT, paramSource);
    }
    
    public int update(Integer id, Order order) {
        final SqlParameterSource paramSource = new MapSqlParameterSource()
                .addValue("id", id)
                .addValue("address", order.getAddress())
                .addValue("city", order.getCity())
                .addValue("pincode", order.getPincode())
                .addValue("email", order.getEmail())
                .addValue("mobile_Number", order.getMobile_Number());

        return jdbcTemplate.update(SQL_UPDATE_BY_ID, paramSource);
    }
}
