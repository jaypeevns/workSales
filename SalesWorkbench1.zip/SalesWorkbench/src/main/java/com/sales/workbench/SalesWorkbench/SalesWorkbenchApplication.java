package com.sales.workbench.SalesWorkbench;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class SalesWorkbenchApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(SalesWorkbenchApplication.class, args);
	}

}
