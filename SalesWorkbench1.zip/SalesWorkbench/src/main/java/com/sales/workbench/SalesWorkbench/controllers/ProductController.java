package com.sales.workbench.SalesWorkbench.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sales.workbench.SalesWorkbench.models.Product;
import com.sales.workbench.SalesWorkbench.repository.ProductRepository;

@Controller
@RequestMapping(path="/product")
public class ProductController {
	
	@Autowired
	ProductRepository productRepository;
	
	@GetMapping("/getAllProducts")
    public @ResponseBody Iterable<Product> getAllProducts() {
        return productRepository.findAll();
    }
	
	@PostMapping("/addProducts")
    public @ResponseBody String saveProduct(@RequestBody Product product) {
		productRepository.save(product);

        return String.format("Added %s", product);
    }

}
