package com.sales.workbench.SalesWorkbench.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.sales.workbench.SalesWorkbench.models.Product;

@Repository
public class ProductRepository {
    private static final String SQL_FIND_ALL = "SELECT * FROM PRODUCT";
    private static final String SQL_INSERT = "INSERT INTO PRODUCT "
    		+ "(NAME, PRODUCTPICSID, PRICE, AVALIBILITYSTATUS, PRODUCTDESCRIPTION, HAVERETURNPOLICY, CREATEDAT ) "
    		+ "values(:name, :product_pics_id, :price, :availability_status, :product_description, :have_return_policy, :created_at)";
    
    private static final BeanPropertyRowMapper<Product> ROW_MAPPER = new BeanPropertyRowMapper<>(Product.class); 
    
    @Autowired
    NamedParameterJdbcTemplate jdbcTemplate;
    
    public Iterable<Product> findAll() {
        return jdbcTemplate.query(SQL_FIND_ALL, ROW_MAPPER);
    }

    public int save(Product product) {
        final SqlParameterSource paramSource = new MapSqlParameterSource()
                .addValue("name", product.getName())
                .addValue("product_pics_id", product.getProduct_pics_id())
                .addValue("price", product.getPrice())
                .addValue("availability_status", product.getAvailability_status())
                .addValue("product_description", product.getProduct_description())
                .addValue("have_return_policy", product.getHave_return_policy())
                .addValue("created_at", product.getCreated_at());

        return jdbcTemplate.update(SQL_INSERT, paramSource);
    }
}
