package com.sales.workbench.SalesWorkbench.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sales.workbench.SalesWorkbench.models.Order;
import com.sales.workbench.SalesWorkbench.repository.OrderRepository;

@Controller
@RequestMapping(path="/order")
public class OrderController {
	
	@Autowired
	OrderRepository orderRepository;
	
	@GetMapping("/getAllOrders")
    public @ResponseBody Iterable<Order> getAllOrders() {
        return orderRepository.findAll();
    }
	
	@PostMapping("/addOrder")
    public @ResponseBody String saveOrder(@RequestBody Order order) {
		orderRepository.save(order);

        return String.format("Added %s", order);
    }
	
	@GetMapping("/getOrderById/{id}")
    public @ResponseBody Optional<Order> getOrderById(@PathVariable Integer id) {
        return Optional.ofNullable(orderRepository.findById(id));
    }

    @PatchMapping("/updateOrderById/{id}")
    public @ResponseBody Order update(@PathVariable Integer id, @RequestBody Order order) {
        Order c = orderRepository.findById(id);
        if(order.getAddress() != null)
            c.setAddress(order.getAddress());
        if(order.getMobile_Number() != null)
            c.setMobile_Number(order.getMobile_Number());
        if(order.getCity() != null)
            c.setCity(order.getCity());
        if(order.getPincode() != null)
            c.setPincode(order.getPincode());
        if(order.getEmail() != null)
            c.setEmail(order.getEmail());
        orderRepository.update(id, c);
        return c;
    }

}
