package com.sales.workbench.SalesWorkbench.repository;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.sales.workbench.SalesWorkbench.models.OrderItems;;

@Repository
public class OrderItemRepository {
	private static final String SQL_FIND_BY_ID = "SELECT * FROM ORDERITEMS WHERE ID = :id";
    private static final String SQL_FIND_ALL = "SELECT * FROM ORDERITEMS";
    private static final String SQL_INSERT = "INSERT INTO ORDERITEMS "
    		+ "(ORDERID, PRODUCTID, QUANTITY, ORCERVALUE) "
    		+ "values(:order_id, :product_id, :quantity, :order_value)";
    
    private static final BeanPropertyRowMapper<OrderItems> ROW_MAPPER = new BeanPropertyRowMapper<>(OrderItems.class); 
    
    @Autowired
    NamedParameterJdbcTemplate jdbcTemplate;
    
    public OrderItems findById(Integer id) {
        try {
            final SqlParameterSource paramSource = new MapSqlParameterSource("id", id);
            return jdbcTemplate.queryForObject(SQL_FIND_BY_ID, paramSource, ROW_MAPPER);
        }
        catch (EmptyResultDataAccessException ex) {
            return null;
        }
    }
    
    public Iterable<OrderItems> findAll() {
        return jdbcTemplate.query(SQL_FIND_ALL, ROW_MAPPER);
    }

    public int save(OrderItems orderItems) {
        final SqlParameterSource paramSource = new MapSqlParameterSource()
                .addValue("order_id", orderItems.getOrder_id())
                .addValue("product_id", orderItems.getProduct_id())
                .addValue("quantity", orderItems.getQuantity())
                .addValue("order_value", orderItems.getOrder_value());

        return jdbcTemplate.update(SQL_INSERT, paramSource);
    }
}
