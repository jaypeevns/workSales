package com.sales.workbench.SalesWorkbench.utils;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.FindAndModifyOptions;

import com.sales.workbench.SalesWorkbench.models.MongoDBSequence;
import com.sales.workbench.SalesWorkbench.models.Order;
import com.sales.workbench.SalesWorkbench.models.Product;

public class SequenceGeneratorServiceImpl  implements SequenceGeneratorService{
	@Autowired
	private MongoOperations mongoOperations;
	
	public long generateSequenceForProduct() {
		String seqName = Product.SEQUENCE_NAME;
		Query query = new Query(Criteria.where("_id").is(seqName));
		Update update = new Update();
		//increase sequence id by 1
		update.inc("productSeq", 1);
		//return new increased id
		FindAndModifyOptions options = new FindAndModifyOptions();
		options.returnNew(true);
	    MongoDBSequence counter = mongoOperations.findAndModify(query,update, options.upsert(true),MongoDBSequence.class);
	    return !Objects.isNull(counter) ? counter.getProductSeq() : 1;
	}
	
	public long generateSequenceForOrder() {
		String seqName = Order.SEQUENCE_NAME;
		Query query = new Query(Criteria.where("_id").is(seqName));
		Update update = new Update();
		//increase sequence id by 1
		update.inc("orderSeq", 1);
		//return new increased id
		FindAndModifyOptions options = new FindAndModifyOptions();
		options.returnNew(true);
	    MongoDBSequence counter = mongoOperations.findAndModify(query,update, options.upsert(true),MongoDBSequence.class);
	    return !Objects.isNull(counter) ? counter.getOrderSeq() : 1;
	}
}
