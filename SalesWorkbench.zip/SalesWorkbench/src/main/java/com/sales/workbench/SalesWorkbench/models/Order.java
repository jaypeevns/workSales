package com.sales.workbench.SalesWorkbench.models;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "orders")
public class Order {
	@Id
	private String id;
    @Transient
    public static final String SEQUENCE_NAME = "order_sequence";
    
    private String order_id;
    private String [] product_ids;
    private String user_id;
    private String order_value;
    private String address;
    private String city;
    private String pincode;
    private String email;
    private String mobile_Number;
    private String payment_mode;
    private String is_returned;
    private String created_at;
	
	public Order() {
    }
	
	public Order(String order_id, String[] product_ids, String user_id, String order_value, String address, String city,
			String pincode, String email, String mobile_Number, String payment_mode, String is_returned,
			String created_at) {
		super();
		this.order_id = order_id;
		this.product_ids = product_ids;
		this.user_id = user_id;
		this.order_value = order_value;
		this.address = address;
		this.city = city;
		this.pincode = pincode;
		this.email = email;
		this.mobile_Number = mobile_Number;
		this.payment_mode = payment_mode;
		this.is_returned = is_returned;
		this.created_at = created_at;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getOrder_value() {
		return order_value;
	}

	public void setOrder_value(String order_value) {
		this.order_value = order_value;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile_Number() {
		return mobile_Number;
	}

	public void setMobile_Number(String mobile_Number) {
		this.mobile_Number = mobile_Number;
	}

	public String getPayment_mode() {
		return payment_mode;
	}

	public void setPayment_mode(String payment_mode) {
		this.payment_mode = payment_mode;
	}

	public String getIs_returned() {
		return is_returned;
	}

	public void setIs_returned(String is_returned) {
		this.is_returned = is_returned;
	}

	public String getCreated_at() {
		return created_at;
	}

	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}

	/**
	 * @return the order_id
	 */
	public String getOrder_id() {
		return order_id;
	}

	/**
	 * @param order_id the order_id to set
	 */
	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}

	/**
	 * @return the product_ids
	 */
	public String [] getProduct_ids() {
		return product_ids;
	}

	/**
	 * @param product_ids the product_ids to set
	 */
	public void setProduct_ids(String [] product_ids) {
		this.product_ids = product_ids;
	}
}
