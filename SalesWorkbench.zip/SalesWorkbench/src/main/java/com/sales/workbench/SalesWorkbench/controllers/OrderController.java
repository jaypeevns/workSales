package com.sales.workbench.SalesWorkbench.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sales.workbench.SalesWorkbench.models.Order;
import com.sales.workbench.SalesWorkbench.repository.OrderRepository;

@RestController
public class OrderController {
	
	@Autowired
	OrderRepository orderRepository;
	
	@RequestMapping(method=RequestMethod.GET, value="/getAllOrders")
    public Iterable<Order> getAllOrders() {
        return orderRepository.findAll();
    }
	
	@RequestMapping(method=RequestMethod.POST, value="/addOrders")
    public Order saveOrder(@RequestBody Order order) {
		orderRepository.save(order);

        return order;
    }
	
	@RequestMapping(method=RequestMethod.GET, value="/getOrderById/{id}")
    public Optional<Order> getOrderById(@PathVariable String id) {
        return orderRepository.findById(id);
    }

    @RequestMapping(method=RequestMethod.PUT, value="/updateOrderById/{id}")
    public Order update(@PathVariable String id, @RequestBody Order order) {
        Optional<Order> optcontact = orderRepository.findById(id);
        Order c = optcontact.get();
        if(order.getAddress() != null)
            c.setAddress(order.getAddress());
        if(order.getMobile_Number() != null)
            c.setMobile_Number(order.getMobile_Number());
        if(order.getCity() != null)
            c.setCity(order.getCity());
        if(order.getPincode() != null)
            c.setPincode(order.getPincode());
        if(order.getEmail() != null)
            c.setEmail(order.getEmail());
        orderRepository.save(c);
        return c;
    }

}
