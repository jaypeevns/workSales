package com.sales.workbench.SalesWorkbench.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "products")
public class Product {
	@Id
	private String id;
    @Transient
    public static final String SEQUENCE_NAME = "product_sequence";
    
    private long product_id;
    private String name;
    private String product_pics_id;
    private String price;
    private String availability_status;
    private String product_description;
    private String have_return_policy;
    private String created_at;
    
    public Product() {
    }
    
	public Product(long product_id, String name, String product_pics_id, String price, String availability_status,
			String product_description, String have_return_policy, String created_at) {
		super();
		this.product_id = product_id;
		this.name = name;
		this.product_pics_id = product_pics_id;
		this.price = price;
		this.availability_status = availability_status;
		this.product_description = product_description;
		this.have_return_policy = have_return_policy;
		this.created_at = created_at;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProduct_pics_id() {
		return product_pics_id;
	}

	public void setProduct_pics_id(String product_pics_id) {
		this.product_pics_id = product_pics_id;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getAvailability_status() {
		return availability_status;
	}

	public void setAvailability_status(String availability_status) {
		this.availability_status = availability_status;
	}

	public String getProduct_description() {
		return product_description;
	}

	public void setProduct_description(String product_description) {
		this.product_description = product_description;
	}

	public String getHave_return_policy() {
		return have_return_policy;
	}

	public void setHave_return_policy(String have_return_policy) {
		this.have_return_policy = have_return_policy;
	}

	public String getCreated_at() {
		return created_at;
	}

	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}

	/**
	 * @return the product_id
	 */
	public long getProduct_id() {
		return product_id;
	}

	/**
	 * @param product_id the product_id to set
	 */
	public void setProduct_id(long product_id) {
		this.product_id = product_id;
	}
}
