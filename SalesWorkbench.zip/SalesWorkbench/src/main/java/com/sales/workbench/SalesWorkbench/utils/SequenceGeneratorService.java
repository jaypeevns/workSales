package com.sales.workbench.SalesWorkbench.utils;


public interface SequenceGeneratorService {
	long generateSequenceForProduct();
	long generateSequenceForOrder();
}
