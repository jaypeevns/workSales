package com.sales.workbench.SalesWorkbench.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "mongo_db_sequence")
public class MongoDBSequence {
    @Id
    private String id;
    private long productSeq;
    private long orderSeq;
    
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public long getProductSeq() {
		return productSeq;
	}
	public void setProductSeq(long productSeq) {
		this.productSeq = productSeq;
	}
	/**
	 * @return the orderSeq
	 */
	public long getOrderSeq() {
		return orderSeq;
	}
	/**
	 * @param orderSeq the orderSeq to set
	 */
	public void setOrderSeq(long orderSeq) {
		this.orderSeq = orderSeq;
	}
    
}
