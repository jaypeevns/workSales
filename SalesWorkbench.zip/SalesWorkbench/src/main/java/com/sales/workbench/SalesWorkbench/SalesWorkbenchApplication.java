package com.sales.workbench.SalesWorkbench;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalesWorkbenchApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalesWorkbenchApplication.class, args);
	}

}
