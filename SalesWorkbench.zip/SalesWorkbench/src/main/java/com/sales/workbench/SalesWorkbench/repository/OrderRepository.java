package com.sales.workbench.SalesWorkbench.repository;

import org.springframework.data.repository.CrudRepository;

import com.sales.workbench.SalesWorkbench.models.Order;

public interface OrderRepository extends CrudRepository<Order, String> {
	@Override
	void delete(Order deleted);
}
