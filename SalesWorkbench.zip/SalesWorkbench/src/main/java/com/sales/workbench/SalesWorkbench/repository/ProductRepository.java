package com.sales.workbench.SalesWorkbench.repository;

import org.springframework.data.repository.CrudRepository;

import com.sales.workbench.SalesWorkbench.models.Product;

public interface ProductRepository extends CrudRepository<Product, String> {
	@Override
	void delete(Product deleted);
}
