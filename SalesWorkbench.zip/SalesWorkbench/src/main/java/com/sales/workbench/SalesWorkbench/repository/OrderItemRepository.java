package com.sales.workbench.SalesWorkbench.repository;

import org.springframework.data.repository.CrudRepository;

import com.sales.workbench.SalesWorkbench.models.OrderItems;;

public interface OrderItemRepository extends CrudRepository<OrderItems, String> {
	@Override
	void delete(OrderItems deleted);
}
