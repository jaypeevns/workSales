package com.sales.workbench.SalesWorkbench.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sales.workbench.SalesWorkbench.models.Product;
import com.sales.workbench.SalesWorkbench.repository.ProductRepository;
import com.sales.workbench.SalesWorkbench.utils.SequenceGeneratorService;
import com.sales.workbench.SalesWorkbench.utils.SequenceGeneratorServiceImpl;

@RestController
public class ProductController {
	
	@Autowired
	ProductRepository productRepository;
	/*@Autowired
	SequenceGeneratorService sequence;*/
	
	@RequestMapping(method=RequestMethod.GET, value="/getAllProducts")
    public Iterable<Product> getAllProducts() {
        return productRepository.findAll();
    }
	
	@RequestMapping(method=RequestMethod.POST, value="/addProducts")
    public Product saveProduct(@RequestBody Product product) {
		SequenceGeneratorService sequence = new SequenceGeneratorServiceImpl();
		product.setProduct_id(sequence.generateSequenceForProduct());
		productRepository.save(product);

        return product;
    }

}
