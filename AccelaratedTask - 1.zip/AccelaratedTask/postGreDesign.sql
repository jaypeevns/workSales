CREATE TABLE "orders" (
  "id" int PRIMARY KEY,
  "product_ids" varchar,
  "user_id" int UNIQUE NOT NULL,
  "order_value" int,
  "address" varchar,
  "mobile_number" varchar,
  "payment_mode" varchar,
  "paymentStatus" varchar,
  "is_returned" boolean,
  "created_at" varchar
);

COMMENT ON COLUMN "orders"."product_ids" IS 'contain all product ids';

COMMENT ON COLUMN "orders"."created_at" IS 'When order created';

CREATE TABLE "order_items" (
  "order_id" int,
  "product_id" int,
  "quantity" int
);

CREATE TABLE "products" (
  "id" int PRIMARY KEY,
  "name" varchar,
  "ProductPicsId" int,
  "price" int,
  "status" varchar,
  "created_at" varchar,
  "ProductDescription" varchar,
  "HasReturnPolicy" varchar
);

ALTER TABLE "order_items" ADD FOREIGN KEY ("order_id") REFERENCES "orders" ("id");

ALTER TABLE "order_items" ADD FOREIGN KEY ("product_id") REFERENCES "products" ("id");