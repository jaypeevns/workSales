CREATE TABLE `orders`
(
  `id` int PRIMARY KEY,
  `product_ids` varchar(255) COMMENT 'contain all product ids',
  `user_id` int UNIQUE NOT NULL,
  `order_value` int,
  `address` varchar(255),
  `mobile_number` varchar(255),
  `payment_mode` varchar(255),
  `paymentStatus` varchar(255),
  `is_returned` boolean,
  `created_at` varchar(255) COMMENT 'When order created'
);

CREATE TABLE `order_items`
(
  `order_id` int,
  `product_id` int,
  `quantity` int
);

CREATE TABLE `products`
(
  `id` int PRIMARY KEY,
  `name` varchar(255),
  `ProductPicsId` int,
  `price` int,
  `status` varchar(255),
  `created_at` varchar(255),
  `ProductDescription` varchar(255),
  `HasReturnPolicy` varchar(255)
);

ALTER TABLE `order_items` ADD FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`);

ALTER TABLE `order_items` ADD FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);
